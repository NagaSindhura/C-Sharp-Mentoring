﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samples
{
    public sealed class DrawApp : IDrawApp
    {

        private class NestedClass
        {
            public NestedClass()
            {
                
            }
        }


        public void SayHi(string toWhom)
        {
            var inst = new NestedClass();
        }

        public void DrawLayer()
        {
            throw new NotImplementedException();
        }

        public void DrawImage()
        {
            throw new NotImplementedException();
        }

        public void DrawMask()
        {
            throw new NotImplementedException();
        }

        public int Prop { get; set; }
    }
}
