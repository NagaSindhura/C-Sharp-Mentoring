﻿namespace samples
{
    public abstract class SpriteBase
    {
        protected abstract void Render();
    }
}