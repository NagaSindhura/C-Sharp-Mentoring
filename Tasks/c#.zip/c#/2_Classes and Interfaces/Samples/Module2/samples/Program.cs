﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace samples
{
    class Program
    {
        static void Main(string[] args)
        {
            //var homeSprite  = new HomePageSprite();
            //homeSprite.DrawHomePage();

            //var contsctsPage  = new ContactsPageSprite();
            //contsctsPage.DrawContactsPage();

            //var drawApp = new DrawApp();
            //////


            //var obj = drawApp as IDrawApp;
            //var obj1 = (IDrawApp)drawApp;

            var obj = new DrawApp.NestedClass();

        }
    }



    public abstract class MainSprite : SpriteBase
    {
        protected override sealed void Render()
        {
            DrawLayer();
            DrawImage();
            DrawMask();
        }

        protected abstract void DrawLayer();
        protected abstract void DrawImage();
        protected abstract void DrawMask();
    }

    public class HomePageSprite : MainSprite
    {
        public void DrawHomePage()
        {
            SayHi();
            base.Render();
        }

        public void SayHi()
        {
            Console.WriteLine("Hi!");
        }
        protected override void DrawLayer()
        {
            Console.WriteLine("DrawLayer!");
        }

        protected override void DrawImage()
        {
            Console.WriteLine("DrawImage!");
        }

        protected override void DrawMask()
        {
            Console.WriteLine("DrawMask!");
        }
    }

    public class ContactsPageSprite : MainSprite
    {
        public void DrawContactsPage()
        {
            SayHello();
            base.Render();
        }

        public void SayHello()
        {
            Console.WriteLine("Hello!");
        }
        protected override void DrawLayer()
        {
            Console.WriteLine("DrawLayer!!");
        }

        protected override void DrawImage()
        {
            Console.WriteLine("DrawImage!!");
        }

        protected override void DrawMask()
        {
            Console.WriteLine("DrawMask!!");
        }
    }



}
