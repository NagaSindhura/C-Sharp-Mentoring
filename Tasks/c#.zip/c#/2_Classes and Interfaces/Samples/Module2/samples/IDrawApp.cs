﻿namespace samples
{
    public interface IDrawApp
    {

        void DrawLayer();
        void DrawImage();
        void DrawMask();

        int Prop { get; set; }
    }
}