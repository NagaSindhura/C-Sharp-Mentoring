﻿using System;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            //ExampleToString();

            //ExampleEquals();

            var p1 = new Person {Id = 1, Name = "Name1"};
            var p2 = new Person {Id = 1, Name = "Name1"};


        }

        /// <summary>
        /// Example for using equals and gethashcode overriding
        /// </summary>
        private static void ExampleEquals()
        {
            //equals for reference type

            Person first = new Person() { FirstName = "Ivan", LastName = "Ivanov" };
            Person second = new Person() { FirstName = "Ivan", LastName = "Ivanov" };
            Person third = new Person() { FirstName = "Ivan", LastName = "Petrov" };

            Console.WriteLine("First is {0}", first.ToString());
            Console.WriteLine("Second is {0}", second.ToString());
            Console.WriteLine("Third is {0}", third.ToString());

            Console.WriteLine("First hash code {0}", first.GetHashCode());
            Console.WriteLine("Second hash code {0}", second.GetHashCode());
            Console.WriteLine("Third hash code {0}", third.GetHashCode());


            Console.WriteLine("First {0} second", first.Equals(second) ? "equals" : "not equals");
            Console.WriteLine("First {0} third", first.Equals(third) ? "equals" : "not equals");

            //equals for value type

            int x = 10;
            int y = 10;
            byte z = 10;

            // hash code equals for each variables
            Console.WriteLine("x hash code {0}", x.GetHashCode());
            Console.WriteLine("y hash code {0}", y.GetHashCode());
            Console.WriteLine("z hash code {0}", z.GetHashCode());


            Console.WriteLine("x {0} y", x.Equals(y) ? "equals" : "not equals");
            Console.WriteLine("x {0} z", x.Equals(z) ? "equals" : "not equals");

        }

        /// <summary>
        /// Example for override ToString() method
        /// </summary>
        static void ExampleToString()
        {
            var person = new Person();
            person.FirstName = "John";
            person.LastName = "Doe";

            Console.WriteLine("Person to string is {0}", person.ToString());
        }

        public class Person
        {
            public int IdInt32 { get; set; }
            public string Name { get; set; }
        } 
        public class PersonEquatable : IEquatable<PersonEquatable>
        {
            private string uniqueSsn;
            private string lName;

            public PersonEquatable(string lastName, string ssn)
            {
                uniqueSsn = ssn;
                this.LastName = lastName;
            }

            public string SSN
            {
                get { return this.uniqueSsn; }
            }

            public string LastName
            {
                get { return this.lName; }
                set
                {
                    if (String.IsNullOrEmpty(value))
                        throw new ArgumentException("The last name cannot be null or empty.");
                    else
                        this.lName = value;
                }
            }

            public bool Equals(PersonEquatable other)
            {
                if (other == null)
                    return false;

                if (this.uniqueSsn == other.uniqueSsn)
                    return true;
                else
                    return false;
            }

            public override bool Equals(Object obj)
            {
                if (obj == null)
                    return false;

                Person personObj = obj as Person;
                if (personObj == null)
                    return false;
                else
                    return Equals(personObj);
            }

            public override int GetHashCode()
            {
                return this.SSN.GetHashCode();
            }

            public static bool operator ==(Person person1, Person person2)
            {
                if (((object)person1) == null || ((object)person2) == null)
                    return Object.Equals(person1, person2);

                return person1.Equals(person2);
            }

            public static bool operator !=(Person person1, Person person2)
            {
                if (((object)person1) == null || ((object)person2) == null)
                    return !Object.Equals(person1, person2);

                return !(person1.Equals(person2));
            }
        }
    }
}
