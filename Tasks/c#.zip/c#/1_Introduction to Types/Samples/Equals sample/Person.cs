﻿namespace ConsoleApplication3
{
    class Person
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        //uncomment this for ToString example

        //public override string ToString()
        //{
        //    return string.Format("{0} {1}", FirstName, LastName);
        //}

        protected bool Equals(Person other)
        {
            return string.Equals(FirstName, other.FirstName) && string.Equals(LastName, other.LastName);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((FirstName != null ? FirstName.GetHashCode() : 0)*397) ^ (LastName != null ? LastName.GetHashCode() : 0);
            }
        }

        public override bool Equals(object obj)
        {
            //check for refernce type
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;

            //check for equal types
            if (obj.GetType() != this.GetType()) return false;

            return Equals((Person) obj);
        }
    }
}
