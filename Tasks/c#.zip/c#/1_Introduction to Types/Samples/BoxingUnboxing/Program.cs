﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace BoxingUnboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            //FirstExample();

           //SecondExample();

           // ThirdExample();

           FourthExample();
        }

        private static void FirstExample()
        {
            MyHandler userHandler = new MyHandler(123);

            try
            {
                //do something
            }
            finally
            {
                userHandler.Dispose();
            }

            Debug.Assert(userHandler.Handler == 0);
        }

        private static void SecondExample()
        {
            MyHandler userHandler = new MyHandler(123);

            //try
            //{
            //    //do something
            //}
            //finally
            //{
            //    ((IDisposable)userHandler).Dispose();
            //}

            //Debug.Assert(userHandler.Handler == 0);

            using (userHandler)
            {
                Console.WriteLine("{0}", userHandler.Handler);
            }

            Console.WriteLine("{0}", userHandler.Handler);

            Debug.Assert(userHandler.Handler == 0);
        }

        private static void ThirdExample()
        {
            HashCodeString code = new HashCodeString { Original = "\uA0A2\uA0A2" };

            var result = code.CheckString("hello");

            Debug.Assert(!result);

            result = code.CheckString("");

            Debug.Assert(!result);
        }

        private static void FourthExample()
        {
            KeyValuePair<int, int> value1 = new KeyValuePair<int, int>(10, 20);
            KeyValuePair<int, int> value2 = new KeyValuePair<int, int>(10, 30);

            Console.WriteLine(string.Format("HashCode value1 is {0}, HashCode value2 is {1}", 
                value1.GetHashCode(), value2.GetHashCode()));


            KeyValuePair<int, string> value3 = new KeyValuePair<int, string>(10, "aaa");
            KeyValuePair<int, string> value4 = new KeyValuePair<int, string>(10, "bbb");

            Console.WriteLine(string.Format("HashCode value3 is {0}, HashCode value4 is {1}", 
                value3.GetHashCode(), value4.GetHashCode()));
        }
    }

    struct MyHandler : IDisposable
    {
        public MyHandler(int handler)
        {
            Handler = handler;
        }

        public int Handler { get; private set; }

        public void Dispose()
        {
            //do something
            Console.WriteLine("disposed {0}", Handler);
            if (Handler != 0)
            {
                Handler = 0;
            }

        }
    }

    class HashCodeString
    {
        public string Original { get; set; }

        public bool CheckString(string inputString)
        {
            return Original.GetHashCode() == inputString.GetHashCode();
        }
    }
}
