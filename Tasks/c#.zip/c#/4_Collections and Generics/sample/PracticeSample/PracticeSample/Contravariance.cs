﻿namespace PracticeSample
{
    public class Contravariance
    {
        public static void ShowExample()
        {
            var account = new Account();
            IBank<Account> ordinaryBank = new Bank<Account>();
            ordinaryBank.DoOperation(account);

            var depositAcc = new DepositAccount();
            IBank<DepositAccount> depositBank = ordinaryBank;
            depositBank.DoOperation(depositAcc);
        }

        private interface IBank<in T> where T : Account
        {
            void DoOperation(T account);
        }

        private class Bank<T> : IBank<T> where T : Account
        {
            public void DoOperation(T account)
            {
                account.DoTransfer(typeof(T).Name);
            }
        }
    }
}