﻿namespace PracticeSample
{
    public class Covariance
    {
        public static void ShowExample()
        {
            IBank<DepositAccount> depositBank = new Bank();
            depositBank.DoOperation(typeof(DepositAccount).Name);

            IBank<Account> ordinaryBank = depositBank;
            ordinaryBank.DoOperation(typeof(Account).Name);
        }

        private interface IBank<out T> where T : Account
        {
            T DoOperation(string type);
        }

        private class Bank : IBank<DepositAccount>
        {
            public DepositAccount DoOperation(string type)
            {
                var acc = new DepositAccount();
                acc.DoTransfer(type);
                return acc;
            }
        }
    }
}