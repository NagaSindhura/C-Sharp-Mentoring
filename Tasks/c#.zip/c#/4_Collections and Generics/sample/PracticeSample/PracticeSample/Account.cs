﻿using System;

namespace PracticeSample
{
    public class Account
    {
        public void DoTransfer(string type)
        {
            Console.WriteLine($"{type} Transfer");
        }
    }

    public class DepositAccount : Account
    {
    }
}