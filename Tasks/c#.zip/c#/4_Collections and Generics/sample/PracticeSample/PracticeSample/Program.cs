﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace PracticeSample
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //LinkedList<string> tune = new LinkedList<string>();
            //tune.AddFirst("do");                           // do
            //tune.AddLast("so");                            // do - so

            //tune.AddAfter(tune.First, "re");               // do - re - so
            //tune.AddAfter(tune.First.Next, "mi");          // do - re - mi - so
            //tune.AddBefore(tune.Last, "fa");               // do - re - mi - fa - so

            //tune.RemoveFirst();                             // re - mi - fa - so
            //tune.RemoveLast();                              // re - mi - fa

            //LinkedListNode<string> miNode = tune.Find("mi");
            //tune.Remove(miNode);                           // re - fa
            //tune.AddFirst(miNode);                         // mi - re - fa

            //foreach (string s in tune) Console.WriteLine(s);

            //Queue<int> q = new Queue<int>();
            //q.Enqueue(10);
            //q.Enqueue(20);
            //int[] data = q.ToArray();        // Exports to an array
            //Console.WriteLine(q.Count);      // "2"
            //Console.WriteLine(q.Peek());     // "10"
            //Console.WriteLine(q.Dequeue());  // "10"
            //Console.WriteLine(q.Dequeue());  // "20"
            //Console.WriteLine(q.Dequeue());  // throws an exception (queue empty)

            //Stack<int> stack = new Stack<int>();
            //stack.Push(1);                      //            Stack = 1
            //stack.Push(2);                      //            Stack = 1,2  

            //stack.Push(3);                      //            Stack = 1,2,3
            //Console.WriteLine(stack.Count);     // Prints 3
            //Console.WriteLine(stack.Peek());    // Prints 3,  Stack = 1,2,3
            //Console.WriteLine(stack.Pop());     // Prints 3,  Stack = 1,2
            //Console.WriteLine(stack.Pop());     // Prints 2,  Stack = 1
            //Console.WriteLine(stack.Pop());     // Prints 1,  Stack = <empty>
            //Console.WriteLine(stack.Pop());     // throws exception

            //var test = new MyTestCollection();
            //foreach (var item in test)
            //{
            //    Console.WriteLine(item);
            //}

            //Covariance.ShowExample();
            //Contravariance.ShowExample();

        }
    }

    internal class MyTestCollection : IEnumerable
    {
        IEnumerator IEnumerable.GetEnumerator()
        {
            yield return 10;
        }

        private IEnumerator GetEnumerator()
        {
            yield return 5;
        }
    }
}