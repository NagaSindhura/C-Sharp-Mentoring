﻿namespace ParkingSystem.Interfaces
{
    public interface IParkingSystem
    {
        Floor GetFloor(int floorNumber);
    }
}