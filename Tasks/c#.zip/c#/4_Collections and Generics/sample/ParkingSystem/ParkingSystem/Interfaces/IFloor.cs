﻿namespace ParkingSystem.Interfaces
{
    public interface IFloor
    {
        void ParkCar(Car car);

        void UnParkFirstCar();

        string GetLastParked();

        int GetCountOfCars();

        string GetAllParkedCars();
    }
}