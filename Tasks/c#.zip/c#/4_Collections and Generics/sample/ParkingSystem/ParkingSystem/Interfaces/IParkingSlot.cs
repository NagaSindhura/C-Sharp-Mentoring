﻿namespace ParkingSystem.Interfaces
{
    public interface IParkingSlot
    {
        string GetCarModelName();
    }
}