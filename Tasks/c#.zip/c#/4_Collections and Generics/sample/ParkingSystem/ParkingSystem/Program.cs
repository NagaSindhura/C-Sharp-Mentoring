﻿using System;
using ParkingSystem.Cars;
using ParkingSystem.Interfaces;

namespace ParkingSystem
{
    public class Program
    {
        private static void Main()
        {
            IParkingSystem parkingSystem = new ParkingSystem(4);

            var floor = parkingSystem.GetFloor(2);

            floor.ParkCar(new Opel());
            floor.ParkCar(new Toyota());
            floor.ParkCar(new Mersedes());

            Console.WriteLine("Last parked: {0}\n", floor.GetLastParked());
            Console.WriteLine("Total parked: {0}\n", floor.GetCountOfCars());

            Console.WriteLine("All cars on the floor:\n{0}", floor.GetAllParkedCars());

            floor.UnParkFirstCar();

            Console.WriteLine("All cars on the floor:\n{0}", floor.GetAllParkedCars());
        }
    }
}