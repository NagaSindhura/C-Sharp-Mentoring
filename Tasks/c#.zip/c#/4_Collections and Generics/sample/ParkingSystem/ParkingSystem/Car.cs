﻿namespace ParkingSystem
{
    public abstract class Car
    {
        public abstract string GetCarModel();
    }
}