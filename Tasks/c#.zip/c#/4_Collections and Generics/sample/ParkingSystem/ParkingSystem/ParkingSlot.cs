﻿using ParkingSystem.Interfaces;

namespace ParkingSystem
{
    public class ParkingSlot<TCar> : IParkingSlot
    {
        private TCar Car { get; }

        public ParkingSlot(TCar car)
        {
            Car = car;
        }

        public string GetCarModelName()
        {
            var carInstance = Car as Car;

            return carInstance != null ? carInstance.GetCarModel() : string.Empty;
        }
    }
}