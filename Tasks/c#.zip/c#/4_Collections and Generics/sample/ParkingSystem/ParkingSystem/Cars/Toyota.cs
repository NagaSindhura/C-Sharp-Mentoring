﻿namespace ParkingSystem.Cars
{
    class Toyota: Car
    {
        public override string GetCarModel()
        {
            return GetType().Name;
        }
    }
}