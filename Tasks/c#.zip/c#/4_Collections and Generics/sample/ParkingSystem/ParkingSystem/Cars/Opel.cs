﻿namespace ParkingSystem.Cars
{
    public class Opel : Car
    {
        public override string GetCarModel()
        {
            return GetType().Name;
        }
    }
}