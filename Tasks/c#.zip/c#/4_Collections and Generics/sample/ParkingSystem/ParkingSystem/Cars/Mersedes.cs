﻿namespace ParkingSystem.Cars
{
    internal class Mersedes : Car
    {
        public override string GetCarModel()
        {
            return GetType().Name;
        }
    }
}