﻿using System;
using System.Collections.Generic;
using ParkingSystem.Interfaces;

namespace ParkingSystem
{
    public class ParkingSystem : IParkingSystem
    {
        private readonly int _numberOfFloors;
        private List<Floor> Floors { get; }

        public ParkingSystem(int numberOfFloors)
        {
            _numberOfFloors = numberOfFloors;

            Floors = new List<Floor>();

            for (var i = 0; i < _numberOfFloors; i++)
            {
                Floors.Add(new Floor());
            }
        }

        public Floor GetFloor(int floorNumber)
        {
            if ((floorNumber < 0) || (floorNumber > _numberOfFloors))
            {
                throw new ArgumentOutOfRangeException();
            }

            return Floors[floorNumber];
        }
    }
}