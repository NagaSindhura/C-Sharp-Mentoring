﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ParkingSystem.Interfaces;

namespace ParkingSystem
{
    public class Floor : IFloor
    {
        private Queue<ParkingSlot<Car>> ParkingSlots { get; set; }

        public void ParkCar(Car car)
        {
            if (ParkingSlots == null)
            {
                ParkingSlots = new Queue<ParkingSlot<Car>>();
            }

            ParkingSlots.Enqueue(new ParkingSlot<Car>(car));

            Console.WriteLine("Car parked: {0}", car.GetType().Name);
        }

        public void UnParkFirstCar()
        {
            var dequeued = ParkingSlots.Dequeue();
            Console.WriteLine("Car un-parked: {0}", dequeued.GetCarModelName());
        }

        public string GetLastParked()
        {
            return ParkingSlots.LastOrDefault()?.GetCarModelName();
        }

        public int GetCountOfCars()
        {
            return ParkingSlots.Count;
        }

        public string GetAllParkedCars()
        {
            var carNames = new StringBuilder();

            foreach (var parkingSlot in ParkingSlots)
            {
                carNames.Append(parkingSlot.GetCarModelName());
                carNames.Append(Environment.NewLine);
            }

            return carNames.ToString();
        }
    }
}