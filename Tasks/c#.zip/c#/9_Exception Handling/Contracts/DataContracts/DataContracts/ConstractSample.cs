﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;

namespace DataContracts
{
    public class ConstractSample
    {
        private readonly List<object> _items;

        private int _max;

        public int Max { get; set; }

        public ConstractSample()
        {
            _items = new List<object>();
            Max = 1;
        }

        public int GetAverageValue(int min, int max)
        {
            //Contract.Requires(min < max); 

            return (min + max)/2;
        }

        public void AddDataToList(object item)
        {
            Contract.Requires(item != null, "Item is null");
            //Contract.Ensures(_items.Contains(item));

            _items.Add(item);
            //do smth
            _items.Remove(item);
        }

        [ContractInvariantMethod]
        private void ChackMax()
        {
            Contract.Invariant(Max < 2 && Max > 0);
        }

        public bool CheckListMax(List<int> items)
        {
            Contract.Requires<InvalidDataException>
                (Contract.ForAll(items, item => item > 3)); //Contract.Exists

            return items.Any() && (items.Max() > 20);
        }

        public int CalculateSum(int start, int end)
        {
            Contract.Ensures(Contract.Result<int>() < 17);
            Contract.Ensures(Contract.Result<int>() < Contract.OldValue(end));

            end += start;

            return start + end;
        }

        public void CheckName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name");
            }

            //do smth
            Contract.EndContractBlock();
        }
    }
}