﻿using System.Diagnostics.Contracts;

namespace DataContracts
{
    /// <summary>
    ///  using contracts
    /// </summary>
    [ContractClass(typeof(AdvancedSample))]
    internal interface ISampleInterface
    {
        /// <summary>
        /// name shoulnd't be empty or null
        /// </summary>
        /// <param name="name"></param>
        void CheckName(string name);

        bool CheckAge(int age);
    }
}