﻿using System;
using System.Linq;

namespace DataContracts
{
    internal class Program
    {
        private static void Main()
        {
            //var sample = new ConstractSample();

            //var result = sample.GetAverageValue(18, 15);

            //sample.AddDataToList(new object());

            //sample.Max = 3;

            //var data = sample.CheckListMax(Enumerable.Range(8, 20).ToList());

            ////sample.Max = int.MaxValue - 100;

            ////result = sample.CalculateSum(1, 8);

            var demo = new SampleContractDemo();

            demo.CheckName(string.Empty);
        }
    }

    internal class SampleContractDemo : ISampleInterface
    {
        public void CheckName(string name)
        {
            Console.WriteLine(name);
        }

        public bool CheckAge(int age)
        {
            throw new NotImplementedException();
        }
    }
}