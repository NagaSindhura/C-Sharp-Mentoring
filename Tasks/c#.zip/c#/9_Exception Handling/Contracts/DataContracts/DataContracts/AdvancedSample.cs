﻿using System.Diagnostics.Contracts;

namespace DataContracts
{
    [ContractClassFor(typeof(ISampleInterface))]
    internal sealed class AdvancedSample : ISampleInterface
    {
        public void CheckName(string name)
        {
            Contract.Requires(!string.IsNullOrEmpty(name));
        }

        public bool CheckAge(int age)
        {
            Contract.Requires((age < 100) && (age > 18));
            return false;
        }
    }
}