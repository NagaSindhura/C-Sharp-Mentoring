﻿using Autofac;
using DesignPatterns;
using infrastructure;
using System;

namespace ioc_autofac
{
    class Program
    {
        private static readonly IContainer _container;
        static Program()
        {
            _container = InitializeContainer();
        }

        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Please specify host and database names");
                return;
            }
            var command = new BuildConnectionStringCommand(args[0], args[1]);
            BuildConnectionStringCommandHandler commandHandler = _container.Resolve<BuildConnectionStringCommandHandler>();
            commandHandler.HandleCommand(command);
        }

        private static IContainer InitializeContainer()
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<ConsoleConfigurationDatabaseRepository>().As<IConfigurationDatabaseRepository>();
            builder.RegisterType<ConnectionStringBuilder>().Named<IConnectionStringBuilder>("base");

            #region Logging Builder
            Action<string> loggingFunction = str => { Console.WriteLine($"Logging from IoC setup: {str}"); };
            builder.RegisterDecorator<IConnectionStringBuilder>(
                    (c, inner) => new LoggingConnectionStringBuilder(inner, loggingFunction),
                    fromKey: "base");
            #endregion

            builder.RegisterType<BuildConnectionStringCommandHandler>();

            return builder.Build();
        }
    }
}
