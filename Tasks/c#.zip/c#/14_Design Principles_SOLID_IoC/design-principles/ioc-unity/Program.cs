﻿using DesignPatterns;
using infrastructure;
using Microsoft.Practices.Unity;
using System;

namespace ioc_unity
{
    class Program
    {
        private static readonly UnityContainer _container;
        static Program()
        {
            _container = InitializeUnityContainer();
        }

        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Please specify host and database names");
                return;
            }
            var command = new BuildConnectionStringCommand(args[0], args[1]);
            BuildConnectionStringCommandHandler commandHandler = _container.Resolve<BuildConnectionStringCommandHandler>();
            commandHandler.HandleCommand(command);
        }

        private static UnityContainer InitializeUnityContainer()
        {
            var container = new UnityContainer();
            container.RegisterType<IConfigurationDatabaseRepository, ConsoleConfigurationDatabaseRepository>();

            //container.RegisterType<IConnectionStringBuilder, ConnectionStringBuilder>();

            #region Logging Builder
            container.RegisterType<IConnectionStringBuilder, ConnectionStringBuilder>(name: "base");

            Action<string> loggingFunction = str => { Console.WriteLine($"Logging from IoC setup: {str}"); };
            container.RegisterType<IConnectionStringBuilder, LoggingConnectionStringBuilder>(new InjectionConstructor(
                    new ResolvedParameter<IConnectionStringBuilder>(name: "base"),
                    loggingFunction
                ));
            #endregion

            container.RegisterType<BuildConnectionStringCommandHandler, BuildConnectionStringCommandHandler>();

            return container;
        }
    }
}
