﻿using DesignPatterns;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DesignPrinciplesTests.DesignPatterns
{
    [TestClass]
    public class BuilderTests
    {
        [TestMethod]
        public void ConnectionStringBuilder_should_build_simplest_string()
        {
            // Arrange
            string server = "localhost";
            string db = "myDb";
            IConnectionStringBuilder connectionStringBuilder = new ConnectionStringBuilder()
                .SetHostName(server)
                .SetDatabaseName(db);

            // Act
            string connectionString = connectionStringBuilder
                .Build();

            // Assert
            Assert.AreEqual("Server=localhost,1433;Database=myDb;Trusted_Connection=True;", connectionString);
        }

        [TestMethod]
        public void ConnectionStringBuilder_should_build_custom_connectionString_with_sql_auth()
        {
            // Arrange
            string server = "localhost";
            string db = "myDb";
            IConnectionStringBuilder connectionStringBuilder = new ConnectionStringBuilder()
                .SetHostName(server)
                .SetDatabaseName(db)
                .SetTrustedConnectionFlagTo(false)
                .UseSqlAuthentication("username","securepassword")
                .SetPort(3333);

            // Act
            string connectionString = connectionStringBuilder
                .Build();

            // Assert
            Assert.AreEqual("Server=localhost,3333;Database=myDb;User Id=username;Password = securepassword;", connectionString);
        }

        [TestMethod]
        public void ConnectionStringBuilder_should_build_custom_connectionString_with_windows_auth()
        {
            // Arrange
            string server = "localhost";
            string db = "myDb";
            IConnectionStringBuilder connectionStringBuilder = new ConnectionStringBuilder()
                .SetHostName(server)
                .SetDatabaseName(db)
                .SetTrustedConnectionFlagTo(false)
                .UseWindowsAuthentication()
                .SetPort(3333);

            // Act
            string connectionString = connectionStringBuilder
                .Build();

            // Assert
            Assert.AreEqual("Server=localhost,3333;Database=myDb;Integrated Security=SSPI;", connectionString);
        }
    }
}
