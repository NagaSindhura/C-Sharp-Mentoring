﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DesignPatterns;
using System.Collections.Generic;

namespace DesignPrinciplesTests.DesignPatterns
{
    [TestClass]
    public class DecoratorTests
    {
        [TestMethod]
        public void LoggingConnectionStringBuilder_should_print_action_start_and_end()
        {
            List<string> output = new List<string>(2);
            var loggingConnectionStringBuilder = new LoggingConnectionStringBuilder(
                new ConnectionStringBuilder(), 
                str => {
                    Console.WriteLine(str);
                    output.Add(str);
                });

            loggingConnectionStringBuilder
                .SetHostName("localhost")
                .SetDatabaseName("myDb")
                .SetPort(3333);

            Console.WriteLine(loggingConnectionStringBuilder.Build());

            Assert.IsTrue(output.Contains("Calling SetPort"));
            Assert.IsTrue(output.Contains("Done calling SetPort"));
        }
    }
}
