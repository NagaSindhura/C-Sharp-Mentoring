﻿using System;
using DesignPatterns;

namespace infrastructure
{
    public class ConsoleConfigurationDatabaseRepository : IConfigurationDatabaseRepository
    {
        public void Save(string key, string value)
        {
            Console.WriteLine($"Saving to database: key: {key}; value: {value}");
        }
    }
}
