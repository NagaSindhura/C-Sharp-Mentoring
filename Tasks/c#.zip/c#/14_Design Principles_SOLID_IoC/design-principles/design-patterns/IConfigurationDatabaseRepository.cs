﻿namespace DesignPatterns
{
    public interface IConfigurationDatabaseRepository
    {
        void Save(string key, string value);
    }
}
