﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatterns
{
    public class BuildConnectionStringCommand
    {
        public BuildConnectionStringCommand(string serverName, string databaseName)
        {
            ServerName = serverName;
            DatabaseName = databaseName;
        }
        public string ServerName { get; }
        public string DatabaseName { get; }
    }

    public class BuildConnectionStringCommandHandler
    {
        private readonly IConnectionStringBuilder _connectionStringBuilder;
        private readonly IConfigurationDatabaseRepository _configurationDatabaseRepository;

        public BuildConnectionStringCommandHandler(
            IConnectionStringBuilder connectionStringBuilder,
            IConfigurationDatabaseRepository configurationDatabaseRepository)
        {
            _connectionStringBuilder = connectionStringBuilder;
            _configurationDatabaseRepository = configurationDatabaseRepository;
        }

        public void HandleCommand(BuildConnectionStringCommand command)
        {
            string connectionString = _connectionStringBuilder
                .SetHostName(command.ServerName)
                .SetDatabaseName(command.DatabaseName)
                .Build();

            _configurationDatabaseRepository.Save("mainConnectionString", connectionString);
        }
    } 
}
