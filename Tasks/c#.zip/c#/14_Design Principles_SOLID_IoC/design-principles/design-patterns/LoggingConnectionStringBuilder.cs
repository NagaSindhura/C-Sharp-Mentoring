﻿using System;

namespace DesignPatterns
{
    public class LoggingConnectionStringBuilder : IConnectionStringBuilder
    {
        private readonly IConnectionStringBuilder _instanceToDecorateOver;
        private readonly Action<string> _loggingAction;

        public LoggingConnectionStringBuilder(IConnectionStringBuilder instanceToDecorateOver, Action<string> loggingAction)
        {
            _instanceToDecorateOver = instanceToDecorateOver;
            _loggingAction = loggingAction;
        }

        public IConnectionStringBuilder SetHostName(string hostname)
        {
            _loggingAction("Calling SetHostName");
            _instanceToDecorateOver.SetHostName(hostname);
            _loggingAction("Done calling SetHostName");
            return this;
        }

        public IConnectionStringBuilder SetDatabaseName(string databaseName)
        {
            _loggingAction("Calling SetDatabaseName");
            _instanceToDecorateOver.SetDatabaseName(databaseName);
            _loggingAction("Done calling SetDatabaseName");
            return this;
        }

        public IConnectionStringBuilder UseWindowsAuthentication()
        {
            _loggingAction("Calling UseWindowsAuthentication");
            _instanceToDecorateOver.UseWindowsAuthentication();
            _loggingAction("Done calling UseWindowsAuthentication");
            return this;
        }

        public IConnectionStringBuilder UseSqlAuthentication(string username, string password)
        {
            _loggingAction("Calling UseSqlAuthentication");
            _instanceToDecorateOver.UseSqlAuthentication(username, password);
            _loggingAction("Done calling UseSqlAuthentication");

            return this;
        }

        public IConnectionStringBuilder SetTrustedConnectionFlagTo(bool trustedConnectionFlag)
        {
            _loggingAction("Calling SetTrustedConnectionFlagTo");
            _instanceToDecorateOver.SetTrustedConnectionFlagTo(trustedConnectionFlag);
            _loggingAction("Done calling SetTrustedConnectionFlagTo");

            return this;
        }

        public IConnectionStringBuilder SetPort(int port)
        {
            _loggingAction("Calling SetPort");
            _instanceToDecorateOver.SetPort(port);
            _loggingAction("Done calling SetPort");

            return this;
        }

        public string Build()
        {
            return _instanceToDecorateOver.Build();
        }
    }
}
