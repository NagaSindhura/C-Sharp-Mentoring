﻿using System;
using System.Text;

namespace DesignPatterns
{
    public class ConnectionStringBuilder : IConnectionStringBuilder
    {
        private string _hostname;
        private string _databaseName;
        private bool _useWindowsAuthentication;
        private bool _useSqlAuthentication;
        private bool _trustedConnection = true;
        private int _port = 1433;
        private string _username;
        private string _password;

        public IConnectionStringBuilder SetHostName(string hostname)
        {
            _hostname = hostname;
            return this;
        }

        public IConnectionStringBuilder SetDatabaseName(string databaseName)
        {
            _databaseName = databaseName;
            return this;
        }

        public IConnectionStringBuilder UseWindowsAuthentication()
        {
            if (_useSqlAuthentication)
            {
                throw new InvalidOperationException(
                    "Cannot switch to windows authentication" +
                    " since SQL authentication already enabled");
            }
            _useWindowsAuthentication = true;

            return this;
        }

        public IConnectionStringBuilder UseSqlAuthentication(string username, string password)
        {
            if (_useWindowsAuthentication)
            {
                throw new InvalidOperationException(
                    "Cannot switch to SQL authentication" +
                    " since windows authentication already enabled");
            }
            _useSqlAuthentication = true;
            _username = username;
            _password = password;
            return this;
        }

        public IConnectionStringBuilder SetTrustedConnectionFlagTo(bool trustedConnectionFlag)
        {
            _trustedConnection = trustedConnectionFlag;
            return this;
        }

        public IConnectionStringBuilder SetPort(int port)
        {
            _port = port;
            return this;
        }

        public string Build()
        {
            // Validation
            if (string.IsNullOrWhiteSpace(_hostname) || string.IsNullOrWhiteSpace(_databaseName))
            {
                throw new InvalidOperationException(
                    $"Hostname or database is not set. Hostname: {_hostname}; Database: {_databaseName}"
                );
            }

            var stringBuilder = new StringBuilder();
            stringBuilder.Append($"Server={_hostname},{_port};");
            stringBuilder.Append($"Database={_databaseName};");
            if (_useWindowsAuthentication)
            {
                stringBuilder.Append("Integrated Security=SSPI;");
            }
            if (_useSqlAuthentication)
            {
                stringBuilder.Append($"User Id={_username};Password = {_password};");
            }
            if (_trustedConnection)
            {
                stringBuilder.Append("Trusted_Connection=True;");
            }
            return stringBuilder.ToString();
        }
    }
}
