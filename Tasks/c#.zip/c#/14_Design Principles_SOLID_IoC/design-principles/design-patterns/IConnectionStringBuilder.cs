﻿namespace DesignPatterns
{
    public interface IConnectionStringBuilder
    {
        IConnectionStringBuilder SetHostName(string hostname);
        IConnectionStringBuilder SetDatabaseName(string databaseName);
        IConnectionStringBuilder UseWindowsAuthentication();
        IConnectionStringBuilder UseSqlAuthentication(string username, string password);
        IConnectionStringBuilder SetTrustedConnectionFlagTo(bool trustedConnectionFlag);
        IConnectionStringBuilder SetPort(int port);
        string Build();
    }
}
