﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Person
    {
        public Education Education { get; set; }
    }

    class Education
    {
        public string School { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {

            //string fileUrl = "file";

            // Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            // Console.WriteLine("Culture = {0}",
            //     Thread.CurrentThread.CurrentCulture.DisplayName);
            // Console.WriteLine("(file == FILE) = {0}",
            //     fileUrl.StartsWith("FILE", true, null));
            // Console.WriteLine();

            // Thread.CurrentThread.CurrentCulture = new CultureInfo("tr-TR");
            // Console.WriteLine("Culture = {0}",
            //     Thread.CurrentThread.CurrentCulture.DisplayName);
            // Console.WriteLine("(file == FILE) = {0}",
            //     fileUrl.StartsWith("FILE", true, null));

            // //Without culture specific use Ordinal.. Invariant consider some linguistic features, not cultural
            // Console.WriteLine("file Equals FILE = {0}", fileUrl.Equals("FILE", StringComparison.OrdinalIgnoreCase));



            //=================================
            User firstUser = new User() { Name = null, Age = 20 };


            Type userType = firstUser.GetType();
            PropertyInfo nameInfo = userType.GetProperty("Name");

            string defaultValue = "default";

            if (Attribute.IsDefined(nameInfo, typeof(DefaultStringValueAttribute)))
            {
                DefaultStringValueAttribute result =
                    (DefaultStringValueAttribute)
                        Attribute.GetCustomAttribute(nameInfo, typeof(DefaultStringValueAttribute));

                defaultValue = result.DefaultValue;

            }

            if (firstUser.Name == null)
            {
                firstUser.Name = defaultValue;
            }
            Console.WriteLine($"{firstUser.Name}");
        }
    }

    //How extract value from attribute
    //Attribute to mark string props, if prop not initialized, set default value
    
public class User
    {
        [DefaultStringValue("Aliaksandr")]
        public string Name { get; set; }
        public int Age { get; set; }
    }



    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class DefaultStringValueAttribute : Attribute
    {
        public DefaultStringValueAttribute(string defaultValue)
        {
            DefaultValue = defaultValue;
        }

        public string DefaultValue { get; private set; }
    }
}
